package com.ms.hoopi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoopiApplicationTests {

    @Test
    void contextLoads() {
    }

}
