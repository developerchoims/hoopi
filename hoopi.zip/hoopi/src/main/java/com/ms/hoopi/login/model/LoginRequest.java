package com.ms.hoopi.login.model;

import lombok.Data;

@Data
public class LoginRequest {
    private String usersId;
    private String usersPw;
}
