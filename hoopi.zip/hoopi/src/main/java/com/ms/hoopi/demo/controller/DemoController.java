package com.ms.hoopi.demo.controller;

import com.ms.hoopi.demo.Demo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class DemoController {
    @GetMapping("/hoopi/demo")
    public Demo sendMsg() {
        Demo demo = new Demo();
        demo.setName("똥방구야");
        demo.setId(("바보"));
        log.info("Demo object: {}", demo);
        return demo;
    }
}
