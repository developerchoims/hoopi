package com.ms.hoopi.auth.AuthDto;

public class JwtToken {

    private String grantType;
    private String accessToken;
    private String refreshToken;
}
