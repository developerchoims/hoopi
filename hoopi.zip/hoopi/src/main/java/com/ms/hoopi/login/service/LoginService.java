package com.ms.hoopi.login.service;

public interface LoginService {

}
