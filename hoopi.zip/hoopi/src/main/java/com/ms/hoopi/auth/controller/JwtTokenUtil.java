package com.ms.hoopi.auth.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JwtTokenUtil {

    public static String secretKey = ${"JWT_SECRET_KEY"};

    public static String msg(){
        return secretKey;
    }
}
