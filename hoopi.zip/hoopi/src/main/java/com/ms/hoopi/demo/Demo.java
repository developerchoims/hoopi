package com.ms.hoopi.demo;

import lombok.Data;

@Data
public class Demo {
    private String name;
    private String id;
}
